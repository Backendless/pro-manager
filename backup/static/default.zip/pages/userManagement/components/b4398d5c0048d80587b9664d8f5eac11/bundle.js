define([], () => ({
  /* content */
  /* handler:onMounted */
  ['onMounted'](___arguments) {
      ___arguments.context.dataModel['createBtn'] = 'Create';

  },
  /* handler:onMounted */
  /* content */
}))
