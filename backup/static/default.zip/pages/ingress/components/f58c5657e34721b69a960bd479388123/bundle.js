define([], () => ({
  /* content */
  /* handler:onBeforeUpload */
  ['onBeforeUpload'](___arguments) {
    
  },
  /* handler:onBeforeUpload */
  /* handler:onUploadSuccess */
  ['onUploadSuccess'](___arguments) {
      console.log(___arguments.uploadedFiles);

  },
  /* handler:onUploadSuccess */
  /* handler:onUploadFail */
  ['onUploadFail'](___arguments) {
      (function (componentUid) { ___arguments.context.getComponentByUid(componentUid).reset() })('f58c5657e34721b69a960bd479388123');

  },
  /* handler:onUploadFail */
  /* content */
}))
