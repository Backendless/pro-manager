define([], () => ({
  /* content */
  /* handler:onBeforeUpload */
  ['onBeforeUpload'](___arguments) {
      ___arguments.context.getComponentDataStoreByUid('c285fdb7425cfedb989a67dd73e1e756')['keyFile'] = (___arguments.files[0]);
  throw (new Error('stop'))

  },
  /* handler:onBeforeUpload */
  /* handler:onUploadFail */
  ['onUploadFail'](___arguments) {
      (function (componentUid) { ___arguments.context.getComponentByUid(componentUid).reset() })('ba31d9f22fe6212698ed8209791bf2ab');

  },
  /* handler:onUploadFail */
  /* content */
}))
