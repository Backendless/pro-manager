define([], () => ({
  /* content */
  /* handler:onLeave */
  ['onLeave'](___arguments) {
      localStorage.removeItem('originLoad');

  },
  /* handler:onLeave */
  /* handler:onEnter */
  async ['onEnter'](___arguments) {
    var error, item, certificatesFromServer;

function getObjectProperty(object, propPath) {
  if (typeof propPath !== 'string' || object[propPath] !== undefined) {
    return object[propPath]
  }

  const propsNamesList = propPath.split('.')

  let result = object

  for (let i = 0; i < propsNamesList.length; i++) {
    if (!result || result[propsNamesList[i]] === undefined) {
      return
    }

    result = result[propsNamesList[i]]
  }

  return result
}


  await (async function() {
  	const inputCertName   = document.querySelector('.inputCertName input');
  	const crtFileWrapper = document.querySelector('.ingress__CustomFileCrt');
  	const keyFileWrapper = document.querySelector('.ingress__CustomFileKey');
  	inputCertName.setAttribute('name', 'certName');
  	crtFileWrapper.innerHTML = `<input type="file" name="crtFile" id="crtFile">`
  	keyFileWrapper.innerHTML = `<input type="file" name="keyFile" id="keyFile">`


  })();
  ___arguments.context.pageData['applyBtnLabel'] = 'Apply';
  localStorage.removeItem('originLoad');
  try {
    certificatesFromServer = (await BackendlessUI.Functions.Custom['fn_696a14dd8d2f85be7023c2c4441a65a5']('get', '/manage/cert', null, null));
    certificatesFromServer.push('NO SSL');
    ___arguments.context.pageData['certificates'] = (await Promise.all(certificatesFromServer.map(async item => {; return ({ 'name': item,'value': item });})));

  } catch (error) {
    await BackendlessUI.Functions.Custom['fn_8f16ba2ef5c9c7a7b32d569b3762f6c4'](___arguments.context.pageData, (getObjectProperty(error, 'message')), '#ff0000', ((function (componentUid) { return ___arguments.context.getComponentByUid(componentUid) })('95980ee1806a02128292c7d76666d134')), ((function (componentUid) { return ___arguments.context.getComponentStyleByUid(componentUid) })('95980ee1806a02128292c7d76666d134')), ((function (componentUid) { return ___arguments.context.getComponentStyleByUid(componentUid) })('56af2c373986c15715d6b101723d8d4f')));

  }

  },
  /* handler:onEnter */
  /* content */
}))
