define([], () => ({
  /* content */
  /* handler:onClick */
  onClick(___arguments) {
      console.log('wwwwwwwwwww');

  },
  /* handler:onClick */
  /* content */
}))
