define([], () => ({
  /* content */
  /* handler:onClick */
  ['onClick'](___arguments) {
      ((function (componentUid) { return ___arguments.context.getComponentStyleByUid(componentUid) })('169ca04218c3102f67d1f8aef66f25f5'))['visibility'] = 'visible';
  ((function (componentUid) { return ___arguments.context.getComponentStyleByUid(componentUid) })('169ca04218c3102f67d1f8aef66f25f5'))['opacity'] = 1;
  (function (componentUid, visible) { (function(component){ component.display = !!(typeof visible === 'boolean' ? visible : !component.display ) })(___arguments.context.getComponentByUid(componentUid)) })('169ca04218c3102f67d1f8aef66f25f5', true);

  },
  /* handler:onClick */
  /* content */
}))
