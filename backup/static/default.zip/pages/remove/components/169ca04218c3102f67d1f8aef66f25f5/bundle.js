define([], () => ({
  /* content */
  /* handler:onBeforeUnmount */
  ['onBeforeUnmount'](___arguments) {
      ___arguments.context.pageData['btnRemoveDisabled'] = true;

  },
  /* handler:onBeforeUnmount */
  /* handler:onBeforeMount */
  ['onBeforeMount'](___arguments) {
      ___arguments.context.pageData['btnRemoveDisabled'] = true;

  },
  /* handler:onBeforeMount */
  /* content */
}))
