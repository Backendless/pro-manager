define([], () => ({
  /* content */
  /* handler:onLeave */
  onLeave(___arguments) {
      localStorage.removeItem('originLoad');

  },
  /* handler:onLeave */
  /* handler:onEnter */
  async ['onEnter'](___arguments) {
    var getVersionList, error, getCurrentVersion;

function getObjectProperty(object, propPath) {
  if (typeof propPath !== 'string' || object[propPath] !== undefined) {
    return object[propPath]
  }

  const propsNamesList = propPath.split('.')

  let result = object

  for (let i = 0; i < propsNamesList.length; i++) {
    if (!result || result[propsNamesList[i]] === undefined) {
      return
    }

    result = result[propsNamesList[i]]
  }

  return result
}


  localStorage.removeItem('originLoad');
  if (!(getObjectProperty(___arguments.context.appData, 'pageRemove'))) {
    ___arguments.context.appData['pageRemove'] = true;
  }
  try {
    getCurrentVersion = (await BackendlessUI.Functions.Custom['fn_696a14dd8d2f85be7023c2c4441a65a5']('get', '/system/version/current', null, null));
    ___arguments.context.pageData['currentVersion'] = getCurrentVersion;

  } catch (error) {
    console.log(error);

  }
  try {
    getVersionList = (await BackendlessUI.Functions.Custom['fn_696a14dd8d2f85be7023c2c4441a65a5']('get', '/system/version/', null, null));
    ___arguments.context.pageData['versions'] = (getObjectProperty(getVersionList, 'all'));

  } catch (error) {
    console.log(error);

  }

  },
  /* handler:onEnter */
  /* content */
}))
