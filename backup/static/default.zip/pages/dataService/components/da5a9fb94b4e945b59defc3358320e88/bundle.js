define([], () => ({
  /* content */
  /* handler:onChange */
  async onChange(___arguments) {
    var item;

async function asyncListFilter(sourceList, callback) {
  const list = await Promise.all(sourceList.map(async source => ({
    source,
    value: await callback(source),
  })));

  const resultList = list.filter(item => item.value)

  return resultList.map(item => item.source)
}


  if (((await asyncListFilter((___arguments.context.pageData['description']), async (item) => {


   return ((item['name']) == 'Max relation page size');
  }))[0])['required']) {
    if (___arguments.value) {
      ;(function (componentUid, visible){ (function(component){ component.display = !!(typeof visible === 'boolean' ? visible : !component.display ) })(___arguments.context.getComponentByUid(componentUid)) })('956da196f07cacfdc983a7562c693e0a', false);
    } else {
      ;(function (componentUid, visible){ (function(component){ component.display = !!(typeof visible === 'boolean' ? visible : !component.display ) })(___arguments.context.getComponentByUid(componentUid)) })('956da196f07cacfdc983a7562c693e0a', true);
    }
  }

  },
  /* handler:onChange */
  /* content */
}))
