define([], () => ({
  /* content */
  /* handler:onTooltipTextAssignment */
  async onTooltipTextAssignment(___arguments) {
    var tooltip;


  if (___arguments.context.pageData['description']) {
    tooltip = (await BackendlessUI.Functions.Custom['fn_4f8fe7d853c915840a67685fa058d83f']((___arguments.context.pageData['description']), 'Max bulk create'));
  }

  return tooltip

  },
  /* handler:onTooltipTextAssignment */
  /* content */
}))
