define([], () => ({
  /* content */
  /* handler:onClick */
  async onClick(___arguments) {
      console.log('abc');
  ;await ( async function (pageName, pageData){ BackendlessUI.goToPage(pageName, pageData) })('test', null);

  },
  /* handler:onClick */
  /* content */
}))
