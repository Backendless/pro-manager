define([], () => ({
  /* content */
  /* handler:onDynamicItemsAssignment */
  onDynamicItemsAssignment(___arguments) {
      return (___arguments.context.appData['test'])

  },
  /* handler:onDynamicItemsAssignment */
  /* content */
}))
