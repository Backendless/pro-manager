define([], () => ({
  /* content */
  /* handler:onClick */
  async ['onClick'](___arguments) {
      await (async function() {

  	stopFollow = !stopFollow;
  })();

  },
  /* handler:onClick */
  /* content */
}))
