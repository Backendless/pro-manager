define([], () => ({
  /* content */
  /* handler:onContentAssignment */
  onContentAssignment(___arguments) {
      return ___arguments.context.getComponentDataStoreByUid('924202b19f0ef683e3940a99b258d565')

  },
  /* handler:onContentAssignment */
  /* content */
}))
