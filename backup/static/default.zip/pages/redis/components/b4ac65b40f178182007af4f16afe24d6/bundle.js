define([], () => ({
  /* content */
  /* handler:onMounted */
  onMounted(___arguments) {
      ___arguments.context.pageData['btnSave'] = 'Save';
  ___arguments.context.pageData['btnSaveRestart'] = 'Save and Restart';

  },
  /* handler:onMounted */
  /* content */
}))
