define([], () => ({
  /* content */
  /* handler:onLeave */
  onLeave(___arguments) {
      localStorage.removeItem('originLoad');

  },
  /* handler:onLeave */
  /* handler:onEnter */
  async ['onEnter'](___arguments) {
    function getObjectProperty(object, propPath) {
  if (typeof propPath !== 'string' || object[propPath] !== undefined) {
    return object[propPath]
  }

  const propsNamesList = propPath.split('.')

  let result = object

  for (let i = 0; i < propsNamesList.length; i++) {
    if (!result || result[propsNamesList[i]] === undefined) {
      return
    }

    result = result[propsNamesList[i]]
  }

  return result
}


  localStorage.removeItem('originLoad');
  if (!(getObjectProperty(___arguments.context.appData, 'pageRedis'))) {
    if ((function (componentUid) { return ___arguments.context.getComponentByUid(componentUid) })('766bf461796308dbbad8e8489727e7c2')) {
      (function (componentUid, visible) { (function(component){ component.display = !!(typeof visible === 'boolean' ? visible : !component.display ) })(___arguments.context.getComponentByUid(componentUid)) })('766bf461796308dbbad8e8489727e7c2', false);
    }
    if ((function (componentUid) { return ___arguments.context.getComponentByUid(componentUid) })('98d2fb4586130cee7f8120193c5d4ccf')) {
      ((function (componentUid) { return ___arguments.context.getComponentStyleByUid(componentUid) })('98d2fb4586130cee7f8120193c5d4ccf'))['display'] = 'flex';
    }
    await new Promise(r => setTimeout(r, 1000 || 0));
    if ((function (componentUid) { return ___arguments.context.getComponentByUid(componentUid) })('98d2fb4586130cee7f8120193c5d4ccf')) {
      ((function (componentUid) { return ___arguments.context.getComponentStyleByUid(componentUid) })('98d2fb4586130cee7f8120193c5d4ccf'))['display'] = 'none';
    }
    if ((function (componentUid) { return ___arguments.context.getComponentByUid(componentUid) })('766bf461796308dbbad8e8489727e7c2')) {
      (function (componentUid, visible) { (function(component){ component.display = !!(typeof visible === 'boolean' ? visible : !component.display ) })(___arguments.context.getComponentByUid(componentUid)) })('766bf461796308dbbad8e8489727e7c2', true);
    }
    ___arguments.context.appData['pageRedis'] = true;
  }
  if (getObjectProperty(___arguments.context.appData, 'pageRedis')) {
    if ((function (componentUid) { return ___arguments.context.getComponentByUid(componentUid) })('766bf461796308dbbad8e8489727e7c2')) {
      (function (componentUid, visible) { (function(component){ component.display = !!(typeof visible === 'boolean' ? visible : !component.display ) })(___arguments.context.getComponentByUid(componentUid)) })('766bf461796308dbbad8e8489727e7c2', true);
    }
  }

  },
  /* handler:onEnter */
  /* content */
}))
